### Hello,  welcome to another lesson. This is  all about sharing my process of growth this career path. And I'm all excited about it.

### Python is an amazing programming language and vast number of packages/libraries it has makes it even more exciting.


### So, once again, i implore you to be encouraged by what you're doing on this path, even if it means doing it poorly till you gain mastery over it.

### It will come more naturally as you do it, more consistently.

### I'm just all excited about it all, so
# Let's get started !!!


### This lesson will be mostly about bringing your Learnings in the previous lessons together. And also, you'll be introduced to advanced techniques to make working with Data more efficiently.

### Data extraction (which you'll find yourself doing, almost all of the time) will also be introduced.

### Just do well to follow along with the examples and do it on your own, as well.

### A better way to learn is by doing. So roll your sleeves up and get your hands in motion

### The first step is to import all the libraries you need using the standard convention.

### And remember to include "%matplotlib inline", so your plottings can display without additional effort. Failure to do this means you have to input "plt.show" after any plot for it to be displayed

### The dataset is an excel file gotten from the "WHO" website and is readily available online for the public

## Loading the excel file that contains the dataset and reading it the first 5 values directly from it


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
%matplotlib inline
```


```python
dataset = pd.read_excel("TB Comm_Engage.xlsx", index_col = 0, parse_date = "year")
dataset.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>bmu</th>
      <th>bmu_community_impl</th>
      <th>community_data_available</th>
      <th>bmu_ref_data</th>
      <th>notified_ref</th>
      <th>notified_ref_community</th>
      <th>bmu_rxsupport_data</th>
      <th>bmu_rxsupport_data_coh</th>
      <th>rxsupport_community_coh</th>
      <th>rxsupport_community_succ</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>661.0</td>
      <td>63441.1133</td>
      <td>1089.0</td>
      <td>991.000000</td>
    </tr>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2014</td>
      <td>722.000000</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>661.000000</td>
      <td>15946.000000</td>
      <td>1088.000000</td>
      <td>506.0</td>
      <td>811.0000</td>
      <td>811.0</td>
      <td>811.000000</td>
    </tr>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2015</td>
      <td>708.000000</td>
      <td>539.000000</td>
      <td>1.000000</td>
      <td>539.000000</td>
      <td>35878.000000</td>
      <td>1146.000000</td>
      <td>750.0</td>
      <td>37001.0000</td>
      <td>877.0</td>
      <td>875.000000</td>
    </tr>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2016</td>
      <td>778.000000</td>
      <td>778.000000</td>
      <td>1.000000</td>
      <td>778.000000</td>
      <td>19710.000000</td>
      <td>1857.000000</td>
      <td>778.0</td>
      <td>43046.0000</td>
      <td>1943.0</td>
      <td>1803.000000</td>
    </tr>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2017</td>
      <td>817.000000</td>
      <td>817.000000</td>
      <td>1.000000</td>
      <td>817.000000</td>
      <td>47406.000000</td>
      <td>5214.000000</td>
      <td>778.0</td>
      <td>46640.0000</td>
      <td>4123.0</td>
      <td>29002.339806</td>
    </tr>
  </tbody>
</table>
</div>



#### Checking the shape of the DataFrame


```python
dataset.shape
```




    (558, 15)



#### Checking the size of the DataFrame


```python
dataset.size
```




    8370



#### Checking the various types of data types present in the DataFrame


```python
dataset.dtypes
```




    iso2                         object
    iso3                         object
    iso_numeric                   int64
    g_whoregion                  object
    year                          int64
    bmu                         float64
    bmu_community_impl          float64
    community_data_available    float64
    bmu_ref_data                float64
    notified_ref                float64
    notified_ref_community      float64
    bmu_rxsupport_data          float64
    bmu_rxsupport_data_coh      float64
    rxsupport_community_coh     float64
    rxsupport_community_succ    float64
    dtype: object



#### Checking the indexes of the DataFrame


```python
dataset.index
```




    Index(['Afghanistan', 'Afghanistan', 'Afghanistan', 'Afghanistan',
           'Afghanistan', 'Afghanistan', 'Albania', 'Albania', 'Algeria',
           'Algeria',
           ...
           'Zambia', 'Zambia', 'Zambia', 'Zambia', 'Zimbabwe', 'Zimbabwe',
           'Zimbabwe', 'Zimbabwe', 'Zimbabwe', 'Zimbabwe'],
          dtype='object', name='country', length=558)



#### Checking the columns of the DataFrame


```python
dataset.columns
```




    Index(['iso2', 'iso3', 'iso_numeric', 'g_whoregion', 'year', 'bmu',
           'bmu_community_impl', 'community_data_available', 'bmu_ref_data',
           'notified_ref', 'notified_ref_community', 'bmu_rxsupport_data',
           'bmu_rxsupport_data_coh', 'rxsupport_community_coh',
           'rxsupport_community_succ'],
          dtype='object')



#### Checking the general info of the DataFrame


```python
dataset.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Index: 558 entries, Afghanistan to Zimbabwe
    Data columns (total 15 columns):
    iso2                        558 non-null object
    iso3                        558 non-null object
    iso_numeric                 558 non-null int64
    g_whoregion                 558 non-null object
    year                        558 non-null int64
    bmu                         558 non-null float64
    bmu_community_impl          558 non-null float64
    community_data_available    558 non-null float64
    bmu_ref_data                558 non-null float64
    notified_ref                558 non-null float64
    notified_ref_community      558 non-null float64
    bmu_rxsupport_data          558 non-null float64
    bmu_rxsupport_data_coh      558 non-null float64
    rxsupport_community_coh     558 non-null float64
    rxsupport_community_succ    558 non-null float64
    dtypes: float64(10), int64(2), object(3)
    memory usage: 61.0+ KB


#### Checking summarized aggregated statistics of the DataFrame


```python
dataset.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso_numeric</th>
      <th>year</th>
      <th>bmu</th>
      <th>bmu_community_impl</th>
      <th>community_data_available</th>
      <th>bmu_ref_data</th>
      <th>notified_ref</th>
      <th>notified_ref_community</th>
      <th>bmu_rxsupport_data</th>
      <th>bmu_rxsupport_data_coh</th>
      <th>rxsupport_community_coh</th>
      <th>rxsupport_community_succ</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>count</td>
      <td>558.000000</td>
      <td>558.000000</td>
      <td>558.000000</td>
      <td>558.000000</td>
      <td>558.000000</td>
      <td>558.000000</td>
      <td>558.000000</td>
      <td>558.000000</td>
      <td>558.000000</td>
      <td>5.580000e+02</td>
      <td>558.000000</td>
      <td>558.000000</td>
    </tr>
    <tr>
      <td>mean</td>
      <td>435.387097</td>
      <td>2015.824373</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>6.344111e+04</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>std</td>
      <td>254.444353</td>
      <td>1.557278</td>
      <td>1025.580114</td>
      <td>586.414187</td>
      <td>0.435137</td>
      <td>342.998607</td>
      <td>68396.183520</td>
      <td>11356.906715</td>
      <td>560.306190</td>
      <td>1.531440e+05</td>
      <td>75296.353613</td>
      <td>60548.638313</td>
    </tr>
    <tr>
      <td>min</td>
      <td>4.000000</td>
      <td>2013.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000e+00</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>25%</td>
      <td>218.000000</td>
      <td>2015.000000</td>
      <td>30.000000</td>
      <td>18.000000</td>
      <td>0.000000</td>
      <td>63.000000</td>
      <td>7373.500000</td>
      <td>1062.500000</td>
      <td>57.750000</td>
      <td>1.615525e+04</td>
      <td>2786.500000</td>
      <td>4861.500000</td>
    </tr>
    <tr>
      <td>50%</td>
      <td>430.000000</td>
      <td>2016.000000</td>
      <td>128.000000</td>
      <td>125.500000</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>6.344111e+04</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>75%</td>
      <td>645.250000</td>
      <td>2017.000000</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>1.000000</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>6.344111e+04</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>max</td>
      <td>894.000000</td>
      <td>2018.000000</td>
      <td>9746.000000</td>
      <td>6819.000000</td>
      <td>1.000000</td>
      <td>4278.000000</td>
      <td>687911.000000</td>
      <td>123895.000000</td>
      <td>6018.000000</td>
      <td>1.983615e+06</td>
      <td>803446.000000</td>
      <td>655101.000000</td>
    </tr>
  </tbody>
</table>
</div>



### Checking for null values in the Dataset


```python
dataset.isna().sum()
```




    iso2                        0
    iso3                        0
    iso_numeric                 0
    g_whoregion                 0
    year                        0
    bmu                         0
    bmu_community_impl          0
    community_data_available    0
    bmu_ref_data                0
    notified_ref                0
    notified_ref_community      0
    bmu_rxsupport_data          0
    bmu_rxsupport_data_coh      0
    rxsupport_community_coh     0
    rxsupport_community_succ    0
    dtype: int64




```python
dataset.notna().sum()
```




    iso2                        558
    iso3                        558
    iso_numeric                 558
    g_whoregion                 558
    year                        558
    bmu                         558
    bmu_community_impl          558
    community_data_available    558
    bmu_ref_data                558
    notified_ref                558
    notified_ref_community      558
    bmu_rxsupport_data          558
    bmu_rxsupport_data_coh      558
    rxsupport_community_coh     558
    rxsupport_community_succ    558
    dtype: int64



### There are no null values in the Dataset. Note that's this is as a result of the fact that I'm working with a version of the file that I've worked with and cleaned before now.


### If you get your own version online, it'll be in the raw form and you'll have to clean, prepare manipulate it before bit can be ready for further exploration and analysis

### Now, you need to check the dataset for duplicated values in the DataFrame


```python
dataset.duplicated().sum()
```




    0



### There are no duplicated values in the dataset, and that's makes your tasks faster and easier. Your next line of action is to begin exploration, visualization and representation of  the required insights from the Dataset


```python
dataset.head(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>bmu</th>
      <th>bmu_community_impl</th>
      <th>community_data_available</th>
      <th>bmu_ref_data</th>
      <th>notified_ref</th>
      <th>notified_ref_community</th>
      <th>bmu_rxsupport_data</th>
      <th>bmu_rxsupport_data_coh</th>
      <th>rxsupport_community_coh</th>
      <th>rxsupport_community_succ</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>661.000000</td>
      <td>63441.1133</td>
      <td>1089.000000</td>
      <td>991.000000</td>
    </tr>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2014</td>
      <td>722.000000</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>661.000000</td>
      <td>15946.000000</td>
      <td>1088.000000</td>
      <td>506.000000</td>
      <td>811.0000</td>
      <td>811.000000</td>
      <td>811.000000</td>
    </tr>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2015</td>
      <td>708.000000</td>
      <td>539.000000</td>
      <td>1.000000</td>
      <td>539.000000</td>
      <td>35878.000000</td>
      <td>1146.000000</td>
      <td>750.000000</td>
      <td>37001.0000</td>
      <td>877.000000</td>
      <td>875.000000</td>
    </tr>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2016</td>
      <td>778.000000</td>
      <td>778.000000</td>
      <td>1.000000</td>
      <td>778.000000</td>
      <td>19710.000000</td>
      <td>1857.000000</td>
      <td>778.000000</td>
      <td>43046.0000</td>
      <td>1943.000000</td>
      <td>1803.000000</td>
    </tr>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2017</td>
      <td>817.000000</td>
      <td>817.000000</td>
      <td>1.000000</td>
      <td>817.000000</td>
      <td>47406.000000</td>
      <td>5214.000000</td>
      <td>778.000000</td>
      <td>46640.0000</td>
      <td>4123.000000</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2018</td>
      <td>887.000000</td>
      <td>887.000000</td>
      <td>1.000000</td>
      <td>887.000000</td>
      <td>48421.000000</td>
      <td>7021.000000</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2015</td>
      <td>28.000000</td>
      <td>28.000000</td>
      <td>0.000000</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2016</td>
      <td>28.000000</td>
      <td>232.037879</td>
      <td>0.000000</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>0.000000</td>
      <td>63441.1133</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2014</td>
      <td>271.000000</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>48.000000</td>
      <td>0.0000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2015</td>
      <td>48.000000</td>
      <td>48.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2016</td>
      <td>240.000000</td>
      <td>240.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2017</td>
      <td>250.000000</td>
      <td>17.000000</td>
      <td>0.000000</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2018</td>
      <td>247.000000</td>
      <td>232.037879</td>
      <td>0.000000</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Angola</td>
      <td>AO</td>
      <td>AGO</td>
      <td>24</td>
      <td>AFR</td>
      <td>2014</td>
      <td>193.000000</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Angola</td>
      <td>AO</td>
      <td>AGO</td>
      <td>24</td>
      <td>AFR</td>
      <td>2015</td>
      <td>283.000000</td>
      <td>232.037879</td>
      <td>0.000000</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Angola</td>
      <td>AO</td>
      <td>AGO</td>
      <td>24</td>
      <td>AFR</td>
      <td>2016</td>
      <td>302.000000</td>
      <td>280.000000</td>
      <td>0.000000</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Angola</td>
      <td>AO</td>
      <td>AGO</td>
      <td>24</td>
      <td>AFR</td>
      <td>2017</td>
      <td>302.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>0.000000</td>
      <td>0.0000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Angola</td>
      <td>AO</td>
      <td>AGO</td>
      <td>24</td>
      <td>AFR</td>
      <td>2018</td>
      <td>333.000000</td>
      <td>9.000000</td>
      <td>1.000000</td>
      <td>9.000000</td>
      <td>5276.000000</td>
      <td>5276.000000</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Armenia</td>
      <td>AM</td>
      <td>ARM</td>
      <td>51</td>
      <td>EUR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>66.000000</td>
      <td>63441.1133</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
  </tbody>
</table>
</div>



### For every Dataset, the exploration, visualization and insights you obtain from it depends on the tasks assigned to you.

### For the sake of practice in this lesson, you'll extract some random but valuable insights and plot visualization where necessary, for the sake of practice and building your skills

#### To determine how many unique countries are represented in this Dataset


```python
countries = dataset.index.unique()
countries1 = countries.value_counts().count()
print("There are",countries1,"countries represented in this dataset")
```

    There are 113 countries represented in this dataset


#### The counts for the unique values in columns 'iso2', 'iso3', 'iso_numeric will be the same with that of country counts. But just to be double sure, let's run the following codes


```python
iso2_uniques = dataset.iso2.unique()
iso2_uniques1 = len(iso2_uniques)
print("The number of unique values in \'iso2\' column is", iso2_uniques1)
```

    The number of unique values in 'iso2' column is 112



```python
iso3_uniques = dataset.iso3.unique()
iso3_uniques1 = len(iso3_uniques)
print("The number of uniques values in \'iso3\' column is", iso3_uniques1)
```

    The number of uniques values in 'iso3' column is 113



```python
isonum_uniques = dataset["iso_numeric"].unique()
isonum_uniques1 = len(isonum_uniques)
print("The number of unique values present in \'iso_numeric\' column is", isonum_uniques1)
```

    The number of unique values present in 'iso_numeric' column is 113


#### The number of unique regions represented in this dataset will be checked and confirmed


```python
regions_unique = dataset["g_whoregion"].unique()
regions_unique1 = len(regions_unique)
print("The number of unique regions represented in \'g_whoregion\' column of this dataset is",regions_unique1)
```

    The number of unique regions represented in 'g_whoregion' column of this dataset is 6


#### To check the number of years which the dataset covers. Or simply said, the number of unique years represented in this dataset


```python
years_unique = dataset.year.unique()
years_unique1 = len(years_unique)
print("The number of unique years present in the \'year\' column of this dataset is", years_unique1)
```

    The number of unique years present in the 'year' column of this dataset is 6



```python
print("The range of years covered in the dataset is within the range of year", years_unique.min(),"to", years_unique.max())
```

    The range of years covered in the dataset is within the range of year 2013 to 2018



```python
len(dataset["community_data_available"].unique())
```




    3



### Now, create a DataFrame which gives you a visual clue of the regions and the countries in each region


```python
country_regs = dataset["community_data_available"].groupby([dataset["g_whoregion"], dataset.index])
country_regs1 = country_regs.size()
country_regs11 = country_regs1.unstack(0)
country_regs11
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>g_whoregion</th>
      <th>AFR</th>
      <th>AMR</th>
      <th>EMR</th>
      <th>EUR</th>
      <th>SEA</th>
      <th>WPR</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>2.0</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>6.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Angola</td>
      <td>5.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Armenia</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>5.0</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <td>Venezuela (Bolivarian Republic of)</td>
      <td>NaN</td>
      <td>4.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Viet Nam</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>6.0</td>
    </tr>
    <tr>
      <td>Yemen</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>3.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Zambia</td>
      <td>5.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
    <tr>
      <td>Zimbabwe</td>
      <td>6.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>113 rows × 6 columns</p>
</div>



### Pay attention to the 2 lines of codes below. A Series object was obtained and the "unstack()" method was used on it to convert it to a  DataFrame object.

### As i always say, there's no limitation to the things you can do with the vast amazing toolkits available in the Python libraries.

### Just know your tools and the task you aim to accomplish, then unleash your creativity in getting things done


```python
type(country_regs1)
```




    pandas.core.series.Series




```python
type(country_regs11)
```




    pandas.core.frame.DataFrame



###  Now, it's time to get information about the exact number of countries in each regions


```python
AFR_countries = country_regs11.AFR[country_regs11.AFR > 0]
AFR_countries
print("The number of countries present in the \'AFR\' region is", AFR_countries.count())
```

    The number of countries present in the 'AFR' region is 42



```python
AMR_countries = country_regs11.AMR[country_regs11.AMR > 0]
AMR_countries
print("The number of countries present in the \'AMR\' region is", AMR_countries.count())
```

    The number of countries present in the 'AMR' region is 17



```python
EMR_countries = country_regs11.EMR[country_regs11.EMR > 0]
EMR_countries
print("The number of countries present in the \'EMR\' region is", EMR_countries.count())
```

    The number of countries present in the 'EMR' region is 13



```python
EUR_countries = country_regs11.EUR[country_regs11.EUR > 0]
EUR_countries
print("The number of countries present in the \'EUR\' region is", EUR_countries.count())
```

    The number of countries present in the 'EUR' region is 20



```python
SEA_countries = country_regs11.SEA[country_regs11.SEA > 0]
SEA_countries
print("The number of countries present in the \'SEA\' region is", SEA_countries.count())
```

    The number of countries present in the 'SEA' region is 9



```python
WPR_countries = country_regs11.SEA[country_regs11.SEA > 0]
WPR_countries
print("The number of countries present in the \'WPR\' region is", WPR_countries.count())
```

    The number of countries present in the 'WPR' region is 9


### Next is to determine number of countries and regions that was attended to in the program per year


```python
dataset.head(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>bmu</th>
      <th>bmu_community_impl</th>
      <th>community_data_available</th>
      <th>bmu_ref_data</th>
      <th>notified_ref</th>
      <th>notified_ref_community</th>
      <th>bmu_rxsupport_data</th>
      <th>bmu_rxsupport_data_coh</th>
      <th>rxsupport_community_coh</th>
      <th>rxsupport_community_succ</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>661.000000</td>
      <td>63441.1133</td>
      <td>1089.000000</td>
      <td>991.000000</td>
    </tr>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2014</td>
      <td>722.000000</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>661.000000</td>
      <td>15946.000000</td>
      <td>1088.000000</td>
      <td>506.000000</td>
      <td>811.0000</td>
      <td>811.000000</td>
      <td>811.000000</td>
    </tr>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2015</td>
      <td>708.000000</td>
      <td>539.000000</td>
      <td>1.000000</td>
      <td>539.000000</td>
      <td>35878.000000</td>
      <td>1146.000000</td>
      <td>750.000000</td>
      <td>37001.0000</td>
      <td>877.000000</td>
      <td>875.000000</td>
    </tr>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2016</td>
      <td>778.000000</td>
      <td>778.000000</td>
      <td>1.000000</td>
      <td>778.000000</td>
      <td>19710.000000</td>
      <td>1857.000000</td>
      <td>778.000000</td>
      <td>43046.0000</td>
      <td>1943.000000</td>
      <td>1803.000000</td>
    </tr>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2017</td>
      <td>817.000000</td>
      <td>817.000000</td>
      <td>1.000000</td>
      <td>817.000000</td>
      <td>47406.000000</td>
      <td>5214.000000</td>
      <td>778.000000</td>
      <td>46640.0000</td>
      <td>4123.000000</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2018</td>
      <td>887.000000</td>
      <td>887.000000</td>
      <td>1.000000</td>
      <td>887.000000</td>
      <td>48421.000000</td>
      <td>7021.000000</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2015</td>
      <td>28.000000</td>
      <td>28.000000</td>
      <td>0.000000</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2016</td>
      <td>28.000000</td>
      <td>232.037879</td>
      <td>0.000000</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>0.000000</td>
      <td>63441.1133</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2014</td>
      <td>271.000000</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>48.000000</td>
      <td>0.0000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2015</td>
      <td>48.000000</td>
      <td>48.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2016</td>
      <td>240.000000</td>
      <td>240.000000</td>
      <td>1.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2017</td>
      <td>250.000000</td>
      <td>17.000000</td>
      <td>0.000000</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2018</td>
      <td>247.000000</td>
      <td>232.037879</td>
      <td>0.000000</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Angola</td>
      <td>AO</td>
      <td>AGO</td>
      <td>24</td>
      <td>AFR</td>
      <td>2014</td>
      <td>193.000000</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Angola</td>
      <td>AO</td>
      <td>AGO</td>
      <td>24</td>
      <td>AFR</td>
      <td>2015</td>
      <td>283.000000</td>
      <td>232.037879</td>
      <td>0.000000</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Angola</td>
      <td>AO</td>
      <td>AGO</td>
      <td>24</td>
      <td>AFR</td>
      <td>2016</td>
      <td>302.000000</td>
      <td>280.000000</td>
      <td>0.000000</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Angola</td>
      <td>AO</td>
      <td>AGO</td>
      <td>24</td>
      <td>AFR</td>
      <td>2017</td>
      <td>302.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>0.000000</td>
      <td>0.0000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Angola</td>
      <td>AO</td>
      <td>AGO</td>
      <td>24</td>
      <td>AFR</td>
      <td>2018</td>
      <td>333.000000</td>
      <td>9.000000</td>
      <td>1.000000</td>
      <td>9.000000</td>
      <td>5276.000000</td>
      <td>5276.000000</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Armenia</td>
      <td>AM</td>
      <td>ARM</td>
      <td>51</td>
      <td>EUR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>66.000000</td>
      <td>63441.1133</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
  </tbody>
</table>
</div>



### Next, let's know the number of regions and the specific regions that were attended to in each year

### All information about 2013 activities is extracted below


```python
extract013 = dataset[dataset["year"] == 2013]
extract013.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>bmu</th>
      <th>bmu_community_impl</th>
      <th>community_data_available</th>
      <th>bmu_ref_data</th>
      <th>notified_ref</th>
      <th>notified_ref_community</th>
      <th>bmu_rxsupport_data</th>
      <th>bmu_rxsupport_data_coh</th>
      <th>rxsupport_community_coh</th>
      <th>rxsupport_community_succ</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>661.0</td>
      <td>63441.1133</td>
      <td>1089.0</td>
      <td>991.0</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>0.0</td>
      <td>63441.1133</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <td>Armenia</td>
      <td>AM</td>
      <td>ARM</td>
      <td>51</td>
      <td>EUR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>66.0</td>
      <td>63441.1133</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <td>Azerbaijan</td>
      <td>AZ</td>
      <td>AZE</td>
      <td>31</td>
      <td>EUR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>0.0</td>
      <td>63441.1133</td>
      <td>0.0</td>
      <td>0.0</td>
    </tr>
    <tr>
      <td>Botswana</td>
      <td>BW</td>
      <td>BWA</td>
      <td>72</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>27.0</td>
      <td>63441.1133</td>
      <td>5316.0</td>
      <td>3605.0</td>
    </tr>
  </tbody>
</table>
</div>



### Then, from the Dataset, information about the countries attended to in 2013 will be obtained


```python
countries013 = extract013["year"].groupby(extract013.index)
countries13 = countries013.size()
countries13.head(15)
```




    country
    Afghanistan                         1
    Algeria                             1
    Armenia                             1
    Azerbaijan                          1
    Botswana                            1
    Bulgaria                            1
    Burkina Faso                        1
    Burundi                             1
    Cabo Verde                          1
    Cameroon                            1
    Chad                                1
    Côte d'Ivoire                       1
    Democratic Republic of the Congo    1
    Eritrea                             1
    Ethiopia                            1
    Name: year, dtype: int64



### To determine how many regions and countries were attended to in 2013


```python
regions013 = extract013.year.groupby(extract013["g_whoregion"])
regions13 = regions013.count()
regions13
```




    g_whoregion
    AFR    29
    EMR     2
    EUR     8
    SEA     6
    WPR     4
    Name: year, dtype: int64




```python
print("The number of countries attended to in year 2013 is",countries13.values.sum(),"\n\n\nThe number of regions attended to in year 2013 is",len(regions13.index))
```

    The number of countries attended to in year 2013 is 49 
    
    
    The number of regions attended to in year 2013 is 5



```python
sorted_2013 = regions13.sort_values()
sorted_2013.plot(kind = "barh")
plt.title("Regional Activities For Year \'2013\'", alpha = 0.85)
plt.ylabel("Regions", alpha = 0.7, fontstyle = "italic")
plt.xlabel("Frequency", alpha = 0.7, fontstyle = 'italic')
```




    Text(0.5, 0, 'Frequency')




![png](output_64_1.png)


### All information about 2014 will be extracted


```python
extract014 = dataset[dataset.year == 2014]
extract014.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>bmu</th>
      <th>bmu_community_impl</th>
      <th>community_data_available</th>
      <th>bmu_ref_data</th>
      <th>notified_ref</th>
      <th>notified_ref_community</th>
      <th>bmu_rxsupport_data</th>
      <th>bmu_rxsupport_data_coh</th>
      <th>rxsupport_community_coh</th>
      <th>rxsupport_community_succ</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2014</td>
      <td>722.0</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>661.000000</td>
      <td>15946.000000</td>
      <td>1088.000000</td>
      <td>506.000000</td>
      <td>811.0000</td>
      <td>811.000000</td>
      <td>811.000000</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2014</td>
      <td>271.0</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>48.000000</td>
      <td>0.0000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Angola</td>
      <td>AO</td>
      <td>AGO</td>
      <td>24</td>
      <td>AFR</td>
      <td>2014</td>
      <td>193.0</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Armenia</td>
      <td>AM</td>
      <td>ARM</td>
      <td>51</td>
      <td>EUR</td>
      <td>2014</td>
      <td>66.0</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>66.000000</td>
      <td>1342.000000</td>
      <td>0.000000</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Azerbaijan</td>
      <td>AZ</td>
      <td>AZE</td>
      <td>31</td>
      <td>EUR</td>
      <td>2014</td>
      <td>69.0</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>0.000000</td>
      <td>5781.000000</td>
      <td>0.000000</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
  </tbody>
</table>
</div>



#### To determine the regions and countries that were attended to in the year 2014, the data was extracted from the dataset dataFrame and the needed information was retrieved from it


```python
countries014 = extract014.year.groupby(extract014.index)
countries14 = countries014.count()
countries14
```




    country
    Afghanistan                    1
    Algeria                        1
    Angola                         1
    Armenia                        1
    Azerbaijan                     1
                                  ..
    United Republic of Tanzania    1
    Uzbekistan                     1
    Viet Nam                       1
    Zambia                         1
    Zimbabwe                       1
    Name: year, Length: 75, dtype: int64




```python
regions014 = extract014.year.groupby(extract014["g_whoregion"])
regions14 = regions014.size()
regions14
```




    g_whoregion
    AFR    39
    AMR     3
    EMR     6
    EUR    11
    SEA     9
    WPR     7
    Name: year, dtype: int64




```python
print("The number of countries attended to in year 2014 is",countries14.values.sum(),"\n\n\nThe number of regions attended to in year 2014 is",len(regions14.index))
```

    The number of countries attended to in year 2014 is 75 
    
    
    The number of regions attended to in year 2014 is 6



```python
sorted_2014 = regions14.sort_values()
sorted_2014.plot(kind = "barh")
plt.title("Regional Activities For Year \'2014\'", alpha = 0.85)
plt.ylabel("Regions", alpha = 0.7, fontstyle = "italic")
plt.xlabel("Frequency", alpha = 0.7, fontstyle = 'italic')
```




    Text(0.5, 0, 'Frequency')




![png](output_71_1.png)


### All information about 2015 is extracted


```python
extract015 = dataset[dataset["year"] == 2015]
extract015.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>bmu</th>
      <th>bmu_community_impl</th>
      <th>community_data_available</th>
      <th>bmu_ref_data</th>
      <th>notified_ref</th>
      <th>notified_ref_community</th>
      <th>bmu_rxsupport_data</th>
      <th>bmu_rxsupport_data_coh</th>
      <th>rxsupport_community_coh</th>
      <th>rxsupport_community_succ</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2015</td>
      <td>708.0</td>
      <td>539.000000</td>
      <td>1.0</td>
      <td>539.000000</td>
      <td>35878.000000</td>
      <td>1146.000000</td>
      <td>750.000000</td>
      <td>37001.0000</td>
      <td>877.000000</td>
      <td>875.000000</td>
    </tr>
    <tr>
      <td>Albania</td>
      <td>AL</td>
      <td>ALB</td>
      <td>8</td>
      <td>EUR</td>
      <td>2015</td>
      <td>28.0</td>
      <td>28.000000</td>
      <td>0.0</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2015</td>
      <td>48.0</td>
      <td>48.000000</td>
      <td>1.0</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.0000</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Angola</td>
      <td>AO</td>
      <td>AGO</td>
      <td>24</td>
      <td>AFR</td>
      <td>2015</td>
      <td>283.0</td>
      <td>232.037879</td>
      <td>0.0</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Armenia</td>
      <td>AM</td>
      <td>ARM</td>
      <td>51</td>
      <td>EUR</td>
      <td>2015</td>
      <td>66.0</td>
      <td>0.000000</td>
      <td>0.0</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
  </tbody>
</table>
</div>




```python
extract015["year"].unique()
```




    array([2015], dtype=int64)



### To determine the number of regions and countries that were attended to in the year 2015, the information was extracted from the dataset DataFrame and the needed details was retrieved from it


```python
countries015 = extract015.year.groupby(extract015.index)
countries15 = countries015.count()
countries15.head(15)
```




    country
    Afghanistan                         1
    Albania                             1
    Algeria                             1
    Angola                              1
    Armenia                             1
    Azerbaijan                          1
    Bangladesh                          1
    Belarus                             1
    Benin                               1
    Bhutan                              1
    Bolivia (Plurinational State of)    1
    Bosnia and Herzegovina              1
    Botswana                            1
    Brazil                              1
    Bulgaria                            1
    Name: year, dtype: int64




```python
regions015 = extract015.year.groupby(extract015["g_whoregion"])
regions15 = regions015.size()
regions15
```




    g_whoregion
    AFR    42
    AMR    17
    EMR    13
    EUR    20
    SEA     9
    WPR    12
    Name: year, dtype: int64




```python
print("The number of countries attended to in the year 2015 is",countries15.values.sum(),"\n\n\nThe number p regions attended to in the year 2015 is",len(regions15))
```

    The number of countries attended to in the year 2015 is 113 
    
    
    The number p regions attended to in the year 2015 is 6



```python
sorted_2015 = regions15.sort_values()
sorted_2015.plot(kind = "barh")
plt.title("Regional Activities For Year \'2015\'", alpha = 0.85)
plt.ylabel("Regions", alpha = 0.7, fontstyle = "italic")
plt.xlabel("Frequency", alpha = 0.7, fontstyle = 'italic')
```




    Text(0.5, 0, 'Frequency')




![png](output_79_1.png)


### All information about 2016 is extracted


```python
extract016 = dataset[dataset["year"] == 2016]
extract016.head()
extract016.year.unique()
```




    array([2016], dtype=int64)



### To determine the number of regions and countries that were attended to in the year 2016, the dataset was extracted from the corresponding DataFrame and the needed details was retrieved from there


```python
countries016 = extract016.year.groupby(extract016.index)
countries16 = countries016.count()
countries16.head(15)
```




    country
    Afghanistan                         1
    Albania                             1
    Algeria                             1
    Angola                              1
    Armenia                             1
    Azerbaijan                          1
    Bangladesh                          1
    Belarus                             1
    Benin                               1
    Bhutan                              1
    Bolivia (Plurinational State of)    1
    Bosnia and Herzegovina              1
    Botswana                            1
    Brazil                              1
    Bulgaria                            1
    Name: year, dtype: int64




```python
regions016 = extract016.year.groupby(extract016["g_whoregion"])
region16 = regions016.count()
region16
```




    g_whoregion
    AFR    40
    AMR    17
    EMR    13
    EUR    19
    SEA     9
    WPR    12
    Name: year, dtype: int64




```python
print("The number of countries attended to in the year 2016 is", countries16.values.sum(),"\n\n\nThe number of regions attended to in the year 2016 is", len(region16.index))
```

    The number of countries attended to in the year 2016 is 110 
    
    
    The number of regions attended to in the year 2016 is 6



```python
sorted_2016 = region16.sort_values()
sorted_2016.plot(kind = "barh")
plt.title("Regional Activities For Year \'2016\'", alpha = 0.85)
plt.ylabel("Regions", alpha = 0.7, fontstyle = "italic")
plt.xlabel("Frequency", alpha = 0.7, fontstyle = 'italic')
```




    Text(0.5, 0, 'Frequency')




![png](output_86_1.png)


### All information about 2017 is extracted


```python
extract017 = dataset[dataset.year == 2017]
extract017
extract017.year.unique()
```




    array([2017], dtype=int64)



### To determine the number of regions and countries that was attended to in the year 2017, the details was extracted from dataset DataFrame and the required details was retrieved from there


```python
countries017 = extract017.year.groupby(extract017.index)
countries17 = countries017.count()
countries17
```




    country
    Afghanistan                           1
    Algeria                               1
    Angola                                1
    Armenia                               1
    Azerbaijan                            1
                                         ..
    Venezuela (Bolivarian Republic of)    1
    Viet Nam                              1
    Yemen                                 1
    Zambia                                1
    Zimbabwe                              1
    Name: year, Length: 110, dtype: int64




```python
regions017 = extract017.year.groupby(extract017["g_whoregion"])
regions17 = regions017.count()
regions17
```




    g_whoregion
    AFR    42
    AMR    16
    EMR    13
    EUR    18
    SEA     9
    WPR    12
    Name: year, dtype: int64




```python
print("The number of countries attended to in the year 2017 is",countries17.values.sum(),"\n\n\nThe number of regions attended to in the year 2017 is",len(regions17))
```

    The number of countries attended to in the year 2017 is 110 
    
    
    The number of regions attended to in the year 2017 is 6



```python
sorted_2017 = regions17.sort_values()
sorted_2017.plot(kind = "barh")
plt.title("Regional Activities For Year \'2017\'", alpha = 0.85)
plt.ylabel("Regions", alpha = 0.7, fontstyle = "italic")
plt.xlabel("Frequency", alpha = 0.7, fontstyle = 'italic')
```




    Text(0.5, 0, 'Frequency')




![png](output_93_1.png)


### All information about 2018 is extracted


```python
extract018 = dataset[dataset["year"] == 2018]
extract018
extract018.year.unique()
```




    array([2018], dtype=int64)



### To determine the number of regions and countries that was attended to in the year 2018, the information was extracted from the dataset DataFrame and the necessary details was retrieved from there


```python
countries018 = extract018.year.groupby(extract018.index)
countries18 = countries018.size()
countries18.head(15)
```




    country
    Afghanistan                         1
    Algeria                             1
    Angola                              1
    Azerbaijan                          1
    Bangladesh                          1
    Belarus                             1
    Benin                               1
    Bhutan                              1
    Bolivia (Plurinational State of)    1
    Bosnia and Herzegovina              1
    Botswana                            1
    Brazil                              1
    Bulgaria                            1
    Burkina Faso                        1
    Burundi                             1
    Name: year, dtype: int64




```python
regions018 = extract018.year.groupby(extract018["g_whoregion"])
regions18 = regions018.size()
regions18
```




    g_whoregion
    AFR    42
    AMR    16
    EMR    10
    EUR    13
    SEA     9
    WPR    11
    Name: year, dtype: int64




```python
print("The number of countries attended to in the year 2018 is",countries18.values.sum(),"\n\n\nThe number of regions attended to in the year 2018 is",len(regions18.values))
```

    The number of countries attended to in the year 2018 is 101 
    
    
    The number of regions attended to in the year 2018 is 6



```python
sorted_2018 = regions18.sort_values()
sorted_2018.plot(kind = "barh")
plt.title("Regional Activities For Year \'2018\'", alpha = 0.85)
plt.ylabel("Regions", alpha = 0.7, fontstyle = "italic")
plt.xlabel("Frequency", alpha = 0.7, fontstyle = 'italic')
```




    Text(0.5, 0, 'Frequency')




![png](output_100_1.png)


### I used the below codes to confirm if the total length of the distributed values across various years is equivalent to the total number of values in the actual dataset. 

### This is just a step to double check if my steps and works are correct

### My results proved to be correct


```python
len(countries13.values)+len(countries14.values) + len(countries15.values) + len(countries16.values) + len(countries17.values) + len(countries18.values)
```




    558




```python
dataset.year.count()
```




    558




```python
extract013.head(20)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>bmu</th>
      <th>bmu_community_impl</th>
      <th>community_data_available</th>
      <th>bmu_ref_data</th>
      <th>notified_ref</th>
      <th>notified_ref_community</th>
      <th>bmu_rxsupport_data</th>
      <th>bmu_rxsupport_data_coh</th>
      <th>rxsupport_community_coh</th>
      <th>rxsupport_community_succ</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Afghanistan</td>
      <td>AF</td>
      <td>AFG</td>
      <td>4</td>
      <td>EMR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>661.0</td>
      <td>63441.1133</td>
      <td>1089.000000</td>
      <td>991.000000</td>
    </tr>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>0.0</td>
      <td>63441.1133</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Armenia</td>
      <td>AM</td>
      <td>ARM</td>
      <td>51</td>
      <td>EUR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>66.0</td>
      <td>63441.1133</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Azerbaijan</td>
      <td>AZ</td>
      <td>AZE</td>
      <td>31</td>
      <td>EUR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>0.0</td>
      <td>63441.1133</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Botswana</td>
      <td>BW</td>
      <td>BWA</td>
      <td>72</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>27.0</td>
      <td>63441.1133</td>
      <td>5316.000000</td>
      <td>3605.000000</td>
    </tr>
    <tr>
      <td>Bulgaria</td>
      <td>BG</td>
      <td>BGR</td>
      <td>100</td>
      <td>EUR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>22.0</td>
      <td>63441.1133</td>
      <td>218.000000</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Burkina Faso</td>
      <td>BF</td>
      <td>BFA</td>
      <td>854</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>30.0</td>
      <td>63441.1133</td>
      <td>1569.000000</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Burundi</td>
      <td>BI</td>
      <td>BDI</td>
      <td>108</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>17.0</td>
      <td>63441.1133</td>
      <td>1335.000000</td>
      <td>1320.000000</td>
    </tr>
    <tr>
      <td>Cabo Verde</td>
      <td>CV</td>
      <td>CPV</td>
      <td>132</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>0.0</td>
      <td>63441.1133</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Cameroon</td>
      <td>CM</td>
      <td>CMR</td>
      <td>120</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>0.0</td>
      <td>63441.1133</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Chad</td>
      <td>TD</td>
      <td>TCD</td>
      <td>148</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>0.0</td>
      <td>63441.1133</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Côte d'Ivoire</td>
      <td>CI</td>
      <td>CIV</td>
      <td>384</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>134.0</td>
      <td>63441.1133</td>
      <td>7785.000000</td>
      <td>6115.000000</td>
    </tr>
    <tr>
      <td>Democratic Republic of the Congo</td>
      <td>CD</td>
      <td>COD</td>
      <td>180</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>95.0</td>
      <td>63441.1133</td>
      <td>7202.000000</td>
      <td>6270.000000</td>
    </tr>
    <tr>
      <td>Eritrea</td>
      <td>ER</td>
      <td>ERI</td>
      <td>232</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>69.0</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Ethiopia</td>
      <td>ET</td>
      <td>ETH</td>
      <td>231</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>760.0</td>
      <td>63441.1133</td>
      <td>11314.000000</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Gabon</td>
      <td>GA</td>
      <td>GAB</td>
      <td>266</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>0.0</td>
      <td>63441.1133</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Georgia</td>
      <td>GE</td>
      <td>GEO</td>
      <td>268</td>
      <td>EUR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>1.0</td>
      <td>63441.1133</td>
      <td>29.000000</td>
      <td>26.000000</td>
    </tr>
    <tr>
      <td>Ghana</td>
      <td>GH</td>
      <td>GHA</td>
      <td>288</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>216.0</td>
      <td>63441.1133</td>
      <td>11392.000000</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Guinea</td>
      <td>GN</td>
      <td>GIN</td>
      <td>324</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>55.0</td>
      <td>63441.1133</td>
      <td>1307.000000</td>
      <td>1046.000000</td>
    </tr>
    <tr>
      <td>India</td>
      <td>IN</td>
      <td>IND</td>
      <td>356</td>
      <td>SEA</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>3394.0</td>
      <td>63441.1133</td>
      <td>736069.000000</td>
      <td>655101.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
afr13 = extract013[extract013["g_whoregion"] == 'AFR']
afri13 = afr13.index.size
afri13
```




    29




```python
afr13.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso2</th>
      <th>iso3</th>
      <th>iso_numeric</th>
      <th>g_whoregion</th>
      <th>year</th>
      <th>bmu</th>
      <th>bmu_community_impl</th>
      <th>community_data_available</th>
      <th>bmu_ref_data</th>
      <th>notified_ref</th>
      <th>notified_ref_community</th>
      <th>bmu_rxsupport_data</th>
      <th>bmu_rxsupport_data_coh</th>
      <th>rxsupport_community_coh</th>
      <th>rxsupport_community_succ</th>
    </tr>
    <tr>
      <th>country</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Algeria</td>
      <td>DZ</td>
      <td>DZA</td>
      <td>12</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>0.0</td>
      <td>63441.1133</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Botswana</td>
      <td>BW</td>
      <td>BWA</td>
      <td>72</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>27.0</td>
      <td>63441.1133</td>
      <td>5316.000000</td>
      <td>3605.000000</td>
    </tr>
    <tr>
      <td>Burkina Faso</td>
      <td>BF</td>
      <td>BFA</td>
      <td>854</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>30.0</td>
      <td>63441.1133</td>
      <td>1569.000000</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>Burundi</td>
      <td>BI</td>
      <td>BDI</td>
      <td>108</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>17.0</td>
      <td>63441.1133</td>
      <td>1335.000000</td>
      <td>1320.000000</td>
    </tr>
    <tr>
      <td>Cabo Verde</td>
      <td>CV</td>
      <td>CPV</td>
      <td>132</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>0.0</td>
      <td>63441.1133</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Cameroon</td>
      <td>CM</td>
      <td>CMR</td>
      <td>120</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>0.0</td>
      <td>63441.1133</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Chad</td>
      <td>TD</td>
      <td>TCD</td>
      <td>148</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>0.0</td>
      <td>63441.1133</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>Côte d'Ivoire</td>
      <td>CI</td>
      <td>CIV</td>
      <td>384</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>134.0</td>
      <td>63441.1133</td>
      <td>7785.000000</td>
      <td>6115.000000</td>
    </tr>
    <tr>
      <td>Democratic Republic of the Congo</td>
      <td>CD</td>
      <td>COD</td>
      <td>180</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>95.0</td>
      <td>63441.1133</td>
      <td>7202.000000</td>
      <td>6270.000000</td>
    </tr>
    <tr>
      <td>Eritrea</td>
      <td>ER</td>
      <td>ERI</td>
      <td>232</td>
      <td>AFR</td>
      <td>2013</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>69.0</td>
      <td>63441.1133</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
  </tbody>
</table>
</div>




```python
dataset.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso_numeric</th>
      <th>year</th>
      <th>bmu</th>
      <th>bmu_community_impl</th>
      <th>community_data_available</th>
      <th>bmu_ref_data</th>
      <th>notified_ref</th>
      <th>notified_ref_community</th>
      <th>bmu_rxsupport_data</th>
      <th>bmu_rxsupport_data_coh</th>
      <th>rxsupport_community_coh</th>
      <th>rxsupport_community_succ</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>count</td>
      <td>558.000000</td>
      <td>558.000000</td>
      <td>558.000000</td>
      <td>558.000000</td>
      <td>558.000000</td>
      <td>558.000000</td>
      <td>558.000000</td>
      <td>558.000000</td>
      <td>558.000000</td>
      <td>5.580000e+02</td>
      <td>558.000000</td>
      <td>558.000000</td>
    </tr>
    <tr>
      <td>mean</td>
      <td>435.387097</td>
      <td>2015.824373</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>6.344111e+04</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>std</td>
      <td>254.444353</td>
      <td>1.557278</td>
      <td>1025.580114</td>
      <td>586.414187</td>
      <td>0.435137</td>
      <td>342.998607</td>
      <td>68396.183520</td>
      <td>11356.906715</td>
      <td>560.306190</td>
      <td>1.531440e+05</td>
      <td>75296.353613</td>
      <td>60548.638313</td>
    </tr>
    <tr>
      <td>min</td>
      <td>4.000000</td>
      <td>2013.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>0.000000e+00</td>
      <td>0.000000</td>
      <td>0.000000</td>
    </tr>
    <tr>
      <td>25%</td>
      <td>218.000000</td>
      <td>2015.000000</td>
      <td>30.000000</td>
      <td>18.000000</td>
      <td>0.000000</td>
      <td>63.000000</td>
      <td>7373.500000</td>
      <td>1062.500000</td>
      <td>57.750000</td>
      <td>1.615525e+04</td>
      <td>2786.500000</td>
      <td>4861.500000</td>
    </tr>
    <tr>
      <td>50%</td>
      <td>430.000000</td>
      <td>2016.000000</td>
      <td>128.000000</td>
      <td>125.500000</td>
      <td>0.549296</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>6.344111e+04</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>75%</td>
      <td>645.250000</td>
      <td>2017.000000</td>
      <td>423.885246</td>
      <td>232.037879</td>
      <td>1.000000</td>
      <td>235.109489</td>
      <td>40706.675277</td>
      <td>7182.249012</td>
      <td>297.073077</td>
      <td>6.344111e+04</td>
      <td>30194.145161</td>
      <td>29002.339806</td>
    </tr>
    <tr>
      <td>max</td>
      <td>894.000000</td>
      <td>2018.000000</td>
      <td>9746.000000</td>
      <td>6819.000000</td>
      <td>1.000000</td>
      <td>4278.000000</td>
      <td>687911.000000</td>
      <td>123895.000000</td>
      <td>6018.000000</td>
      <td>1.983615e+06</td>
      <td>803446.000000</td>
      <td>655101.000000</td>
    </tr>
  </tbody>
</table>
</div>



### Now, let's introduce you to the concept of joining and merging data or datasets using the "pd.concat()" function


```python
regions_concat = pd.concat([regions13,regions14,regions15,region16,regions17,regions18], keys = ["2013","2014","2015","2016","2017","2018"])
regions_concat.head(15)
```




          g_whoregion
    2013  AFR            29
          EMR             2
          EUR             8
          SEA             6
          WPR             4
    2014  AFR            39
          AMR             3
          EMR             6
          EUR            11
          SEA             9
          WPR             7
    2015  AFR            42
          AMR            17
          EMR            13
          EUR            20
    Name: year, dtype: int64




```python
region_concat = regions_concat.unstack(0)
region_concat
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>2013</th>
      <th>2014</th>
      <th>2015</th>
      <th>2016</th>
      <th>2017</th>
      <th>2018</th>
    </tr>
    <tr>
      <th>g_whoregion</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>AFR</td>
      <td>29.0</td>
      <td>39.0</td>
      <td>42.0</td>
      <td>40.0</td>
      <td>42.0</td>
      <td>42.0</td>
    </tr>
    <tr>
      <td>AMR</td>
      <td>NaN</td>
      <td>3.0</td>
      <td>17.0</td>
      <td>17.0</td>
      <td>16.0</td>
      <td>16.0</td>
    </tr>
    <tr>
      <td>EMR</td>
      <td>2.0</td>
      <td>6.0</td>
      <td>13.0</td>
      <td>13.0</td>
      <td>13.0</td>
      <td>10.0</td>
    </tr>
    <tr>
      <td>EUR</td>
      <td>8.0</td>
      <td>11.0</td>
      <td>20.0</td>
      <td>19.0</td>
      <td>18.0</td>
      <td>13.0</td>
    </tr>
    <tr>
      <td>SEA</td>
      <td>6.0</td>
      <td>9.0</td>
      <td>9.0</td>
      <td>9.0</td>
      <td>9.0</td>
      <td>9.0</td>
    </tr>
    <tr>
      <td>WPR</td>
      <td>4.0</td>
      <td>7.0</td>
      <td>12.0</td>
      <td>12.0</td>
      <td>12.0</td>
      <td>11.0</td>
    </tr>
  </tbody>
</table>
</div>



### Just like we've done earlier, the concatenation process yields " A Pandas Series Object", and using the "unstack()" method, it's converted back to "A Pandas DataFrame Object". The details below


```python
type(regions_concat)
```




    pandas.core.series.Series




```python
type(region_concat)
```




    pandas.core.frame.DataFrame




```python
region_concat.columns.name = 'Year'
region_concat
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th>Year</th>
      <th>2013</th>
      <th>2014</th>
      <th>2015</th>
      <th>2016</th>
      <th>2017</th>
      <th>2018</th>
    </tr>
    <tr>
      <th>g_whoregion</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>AFR</td>
      <td>29.0</td>
      <td>39.0</td>
      <td>42.0</td>
      <td>40.0</td>
      <td>42.0</td>
      <td>42.0</td>
    </tr>
    <tr>
      <td>AMR</td>
      <td>NaN</td>
      <td>3.0</td>
      <td>17.0</td>
      <td>17.0</td>
      <td>16.0</td>
      <td>16.0</td>
    </tr>
    <tr>
      <td>EMR</td>
      <td>2.0</td>
      <td>6.0</td>
      <td>13.0</td>
      <td>13.0</td>
      <td>13.0</td>
      <td>10.0</td>
    </tr>
    <tr>
      <td>EUR</td>
      <td>8.0</td>
      <td>11.0</td>
      <td>20.0</td>
      <td>19.0</td>
      <td>18.0</td>
      <td>13.0</td>
    </tr>
    <tr>
      <td>SEA</td>
      <td>6.0</td>
      <td>9.0</td>
      <td>9.0</td>
      <td>9.0</td>
      <td>9.0</td>
      <td>9.0</td>
    </tr>
    <tr>
      <td>WPR</td>
      <td>4.0</td>
      <td>7.0</td>
      <td>12.0</td>
      <td>12.0</td>
      <td>12.0</td>
      <td>11.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
new_region = region_concat.T
new_region.plot(marker = '*')
plt.legend(ncol = 1, loc = (1, 0.57))
```




    <matplotlib.legend.Legend at 0x98ec5850>




![png](output_115_1.png)



```python
new_region.plot(kind = "barh")
plt.legend(ncol = 1, loc = (1, 0.575))
```




    <matplotlib.legend.Legend at 0x98ece270>




![png](output_116_1.png)


### At this juncture I'll leave you to work more on your own and make new discoveries. Python is an amazing programming language with unlimited possibilities to what you can do with it's range of Data Science libraries

### Remember, the best way to learn is by doing, so

# Practice! Practice!! Practice!!!

### And remember to feel encouraged no matter what your progress seems like. With a couple of practice and your commitment, all of the process will come naturally with ease.

### Just keep doing it and improve on your abilities.

### Keep Practicing at your best 


# Happy Learning !


```python

```


```python

```
